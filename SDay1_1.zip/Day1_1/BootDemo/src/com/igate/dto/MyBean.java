package com.igate.dto;

import org.springframework.stereotype.*;
import org.springframework.beans.factory.annotation.*;
/*
 * The bean class with @Component annotation
 * Will be auto detected by the Application runner
 * Author:hg676412
 * Version: 1.0
 */
@Component
public class MyBean {

    @Value("Capgemini")
    private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
