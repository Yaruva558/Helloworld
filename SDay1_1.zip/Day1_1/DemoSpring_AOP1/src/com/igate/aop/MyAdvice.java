package com.igate.aop;

import org.aspectj.lang.ProceedingJoinPoint;

//@Aspect
//Advice  has 3 methods a1,a2,a3
public class MyAdvice {
	
	public int a1() {
		System.out.println("a1--------->Before Method Call");
		return 5;
	}

	public void a2(ProceedingJoinPoint joinpoint) {
		System.out.println("a2-------->Around (Before) Method Call");
		try{
		joinpoint.proceed();
		}catch(Throwable t){}
		System.out.println("a2-------->In excepiton");
		System.out.println("a2-------->Around (After) Method Call");
	}

	public void a3() {
		System.out.println("a3-------->After Method Call");
	}

	
}
