package com.igate.aop;

//Target
public interface Business {
  void doBusiness();
    void m1();
}
