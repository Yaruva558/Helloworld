package com.igate.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Target class - BusinessImpl
public class BusinessImpl{
	//Joinpoints - 2 methods , doBusiness(), m1() 
	//Pointcut - execution(* com.igate.aop.BusinessImpl.doBusiness())
    private void doBusiness() {
            System.out.println("I do what I do best, i.e sleep.");
           try {
            	throw new NullPointerException();
            }catch (Exception e) {
                    System.out.println("How dare you to wake me up?");
            }
            System.out.println("Done with sleeping.");
    }

    private void m1() {
    	System.out.println("Hello...");
    }
    
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("schemaaop.xml");
        BusinessImpl bc = (BusinessImpl)context.getBean("myBusinessClass");
        bc.doBusiness();
        System.out.println("........Calling m1");
        bc.m1();
}
}