package com.igate.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

public class EmployeeDao {
	
	//Template Part -> Manage Connection , Exception -> U should give the credentials
	SimpleJdbcTemplate simpleJdbcTemplate;
	

	public SimpleJdbcTemplate getSimpleJdbcTemplate() {
		return simpleJdbcTemplate;
	}

	public void setSimpleJdbcTemplate(SimpleJdbcTemplate simpleJdbcTemplate) {
		this.simpleJdbcTemplate = simpleJdbcTemplate;
	}
	
	public int getCount()
	{
		int count=0;
		count=simpleJdbcTemplate.queryForInt("select count(*) from employee414");
		return count;
	}
	
	public String getEmployeeName(int id)
	{
		String sql = "SELECT enm from employee414 where eid=?";
		String name=getSimpleJdbcTemplate().queryForObject(sql,String.class,id);
		return name;
	}
	
	public int insertRec(int eid,String enm,double esl)
	{
	    String sql="insert into employee414 values(?,?,?)";   
		Object[] params=new Object[]{eid,enm,esl};
		return simpleJdbcTemplate.update(sql, params);
	}
	
	public int updateRec(int eid,String enm,double esl)
	{
	    String sql="update employee414 set enm=?,esl=? where eid=?";
	    Object[] params = new Object[]{enm,esl,eid};
	    int update=simpleJdbcTemplate.update(sql, params);
	    return update;
	}
	
	public List getAll()
	{
	   Object[] params=new Object[]{new Double(40000.00)};
       List list=simpleJdbcTemplate.queryForList("SELECT * from employee414 where esl > ?",params);
       return list;
    }
	
	// to retrieve the an employee given eid
	public Employee getEmpByEid(int eid) {
		
	String sql = "SELECT eid,enm,esl from employee414 where eid=?";
		
	//RowMapper will tell Spring how to map a row from a table(employee414) into an object - Employee object
	RowMapper mapper = new RowMapper() {
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee e = new Employee();
				e.setEid(rs.getInt(1));
				e.setEnm(rs.getString(2));
				e.setEsl(rs.getDouble(3));
				return e;
			}
		};
		
	Employee employee= (Employee) simpleJdbcTemplate.queryForObject(sql,mapper,eid);
	return employee;
	
	}
	
    public List<Employee> getEmployeeList() 
    {
    	System.out.println("getting employee list");
	   String sql = "SELECT * FROM employee414";
	   List<Employee> eList =simpleJdbcTemplate.query(sql,new EmployeeRowMapper());
	   System.out.println("____________");
	   return eList;
	   
	}

    public Employee getEmpByEidNew(int eid) {
		
    	String sql = "SELECT eid,enm,esl from employee414 where eid=?";
    	
    	Employee employee= (Employee) simpleJdbcTemplate.queryForObject(sql,new EmpMapRowNew(),eid);
    	return employee;
    	
    	}	

}
