package com.igate.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmpMapRowNew implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int line) throws SQLException {
		Employee e = new Employee();
		e.setEid(rs.getInt(1));
		e.setEnm(rs.getString(2));
		e.setEsl(rs.getDouble(3));
	//	System.out.println(line);
		return e;
	}

}
