jQuery.fn.removeAttributes = function() {
	  return this.each(function() {
		var attributes = $.map(this.attributes, function(item) {
		  return item.name;
		});
		var img = $(this);
		$.each(attributes, function(i, item) {
		img.removeAttr(item);
		});
	  });
	}
	var options = [];
jQuery.fn.filterByText = function(textbox) {
	return this.each(function() {
		var select = this;
		$(select).find('option').each(function() {
			options.push({value: $(this).val(), text: $(this).text()});
		});
		$(select).data('options', options);
		$(textbox).bind('change keyup', function() {
			var options = $(select).empty().scrollTop(0).data('options');
			var search = $.trim($(this).val());
			var regex = new RegExp(search,'gi');
			$.each(options, function(i) {
			var option = options[i];
			if(option.text.match(regex) !== null) {
			  $(select).append(
				$('<option>').text(option.text).val(option.value)
			  );
			}
			});
		});
	});
	};
function getdate(){
	var d = new Date();
	var currentMonth = d.getMonth() + 1;
	var currentDay = d.getDate();
	var currentYear = d.getFullYear();			
	//This is the div where we store our last refreshed info (if applicable), 
	//this is in plain JS because each page may not use jQuery
	if(document.getElementById("headerDate") != null){
		document.getElementById('headerDate').value = currentMonth + '/' + currentDay + '/' + currentYear;
	}
}	

var spinnerCnt = 0;
	function showLoading()
	{
		if(spinnerCnt == 0){
			$.blockUI({ 
				centerY: 0, 
				overlayCSS: { backgroundColor: '#000', opacity: .2 },
				message: '<img src="../images/spinner-big.gif" />',
				 css: { 
			        	border: 'none',  
			            backgroundColor: '#fff', 
			            '-webkit-border-radius': '10px', 
			            '-moz-border-radius': '10px',
			            top:  ($(window).height() - 30) /2 + 'px', 
		                left: ($(window).width() - 30) /2 + 'px', 
			            width: '30px',
			            height: '30px'
			        } 
		    });
		}
		spinnerCnt++;
	}
	function stopLoading() {
		if(spinnerCnt == 1){
			$.unblockUI();
		}
		spinnerCnt = (spinnerCnt <= 0) ? 0 : spinnerCnt-1;
	}