//Penske's Internal Common JS

//tabId, if you have secondary nav id of the secondary tab, if only primary nav id of primary nav.
//leftNavId, id of the left nav link you want highlighted, pass in blank if you have no left nav.
function selectCurrentNavigation(tabId,leftNavId){
	
	//Remove onclick return false from primary nav, just incase the caller is using ajax
	$('nav ul li.current > a').attr("onclick","");
	// Apply "current" class to menu item of current page and its parent tab
	$('nav ul li.current').removeClass('current');
	
	//Remove onclick return false from subnav, just incase the caller is using ajax
	$('nav ul li ul li.current > a').attr("onclick","");
	
	$('a[id="' + tabId + '"]').attr("onclick","return false").parent('li').addClass('current').closest('nav > ul > li').addClass('current');
	
	//Make the main nav current tab not clickable
	$('nav ul li.current > a').attr("onclick","return false");
	
	// Apply "activeLeftNav" class to left nav item
	$('a.activeLeftNav').removeClass('current');
	
	//Left Nav
	if(leftNavId != null && leftNavId !='' && leftNavId != ' '){
		//$('a.activeLeftNav').attr("onclick","").removeClass('activeLeftNav');
		//$('a[id="' + leftNavId + '"]').addClass('activeLeftNav').attr("onclick","return false");
		$('a.activeLeftNav').removeClass('activeLeftNav');
		$('a[id="' + leftNavId + '"]').addClass('activeLeftNav');
	}
}

function alertModal(specClass, message, callbacks) {
       // Builds the error message div
       var obj = $('<div><p>' + message + '</p></div>');
       // Calls for the dialog to be created
       var modal = createAlertModal(obj, specClass + 'Modal', callbacks);
}

// Creating alert modal in a separate function to allow for
// manually placing the dialog div in the DOM if needed.
function createAlertModal(obj, specClass, callbacks) {
       return obj.dialog({
              autoOpen: true,
              modal: true,
              dialogClass: specClass,
              width: 500,
              minHeight: 0,
              resizable: false,
              close: function(event, ui){ 
                     // Sets up the dialog to be removed completely from the dom,
                     // so we don't keep piling them up every time we open one
                     $(this).dialog('destroy').remove();
                     if(callbacks != undefined) {
                           for (var i = 0, l = callbacks.length; i < l; i++){
                             (function(i){
                                   callbacks[i]();
                             })(i);
                         }
                     }
              }
       });
}

function getTime(){
	var d = new Date();
	var currentMonth = d.getMonth() + 1;
	var currentDay = d.getDate();
	var currentYear = d.getFullYear();
	
	var currentHour = d.getHours();
	var currentMinutes = d.getMinutes();
	var amPm = '';
	
	if(currentHour > 12){
		amPm = 'pm';
		currentHour = currentHour - 12;
	}else if(currentHour == 12){
		amPm = 'pm';
	}else if(currentHour == 0){
		amPm = 'am';
		currentHour = 12;
	}
	else{
		amPm = 'am';
	}
	
	if(currentMinutes < 10){
		currentMinutes = "0" + currentMinutes;
	}
	
	//This is the div where we store our last refreshed info (if applicable), 
	//this is in plain JS because each page may not use jQuery
	if(document.getElementById("title").children[1] != null){
		document.getElementById('title').children[1].innerHTML = 'Last Refreshed: ' + currentHour + ':' + currentMinutes + amPm + ' ' + currentMonth + '/' + currentDay + '/' + currentYear + ' ';
	}
	
}

function toggleSource(){
	if($('#viewSource').css('display') == 'none'){
		$("#viewSource").show();
		$("#viewSourceLabel").text('Hide Source');
	}else{
		$("#viewSource").hide();
		$("#viewSourceLabel").text('View Source');
	}
};

function getLeftFooter(){
	var d = new Date();
	var currentYear = d.getFullYear();
	
	//This is where we store our left footer info, this is in plain JS because each page may not use jQuery
	//We are using external footer so our HTML structure is different
	if(document.getElementById("leftFooter") != null && document.getElementById("leftFooter").className == 'utility-list')
		document.getElementById("leftFooter").children[0].innerHTML = '&copy; ' + currentYear + ' Penske. All Rights Reserved.';
	else{//internal footer
		document.getElementById("leftFooter").innerHTML = '&copy; ' + currentYear + ' Penske. All Rights Reserved.';
	}
}

function openPrivacyPolicy(){
	var left = parseInt((screen.availWidth/2) - (1024/2));
	var top = parseInt((screen.availHeight/2) - (768/2));
	var features = "width=1024,height=768,left=" + left + ",top=" + top + ",toolbar=no,scrollbars=yes,resizable=yes";
	var url = 'https://www.myfleetatpenske.com/static/static_content/privacy_policy.html'
	var newWin =  window.open(url,'SamplePopup',features);
	newWin.focus();
}

function openTermsAndConditions(){
	var left = parseInt((screen.availWidth/2) - (1024/2));
	var top = parseInt((screen.availHeight/2) - (768/2));
	var features = "width=1024,height=768,left=" + left + ",top=" + top + ",toolbar=no,scrollbars=yes,resizable=yes";
	var url = 'https://www.myfleetatpenske.com/static/static_content/terms_and_conditions.html'
	var newWin =  window.open(url,'SamplePopup',features);
	newWin.focus();	
}

if (typeof jQuery != 'undefined' && jQuery.ui) {
	 //overrides jQuery UI datepicker today button functionality to actually put today's date in the input box.
	$.datepicker._gotoToday = function(id) {
		var target = $(id);
		var inst = this._getInst(target[0]);
		if (this._get(inst, 'gotoCurrent') && inst.currentDay) {
				inst.selectedDay = inst.currentDay;
				inst.drawMonth = inst.selectedMonth = inst.currentMonth;
				inst.drawYear = inst.selectedYear = inst.currentYear;
		}
		else {
				var date = new Date();
				inst.selectedDay = date.getDate();
				inst.drawMonth = inst.selectedMonth = date.getMonth();
				inst.drawYear = inst.selectedYear = date.getFullYear();
				this._setDateDatepicker(target, date);
				this._selectDate(id, this._getDateDatepicker(target));
		}
		this._notifyChange(inst);
		this._adjustDate(target);
	}
}

function setupMenus(element) {
  var filterElement = (!element) ? "" : element + " ";
  $(filterElement + ' .dropmenu')
    .on('mouseleave', 'li', function(event) {
      clearTimeout($(this).data('menutimer'));
      $(this).removeClass('expanded');
    })
    .on('touchend click', 'li.expanded', function(event) {
      $(this).removeClass('expanded');
  });
  $(filterElement + ' .dropmenu')
    .on('mouseenter', 'li:not(".expanded")', function(event) {
      var dropmenu = $(this);
      var menutimer = setTimeout(function() {
        dropmenu.addClass('expanded');
      }, 500);
      dropmenu.data('menutimer', menutimer);
    })
   .on('touchend click', 'li:not(".expanded")', function(event) {
      $(this).addClass('expanded');
  });
}