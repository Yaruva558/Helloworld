package com.igate;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class HelloMain {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("anno.xml");
		
		//Ask the factory to inject a bean with id myAccount
		Account a1=(Account) factory.getBean("savingsAcc");
		System.out.println("a1 = "+a1);
		System.out.println("Customer = "+a1.getC1());
		a1.calculateInterest();
		
		
		
		/*System.out.println("====================");
		System.out.println("====================");
		Account a2=(Account) factory.getBean("savingsAcc");
		System.out.println("a2 = "+a2);
		System.out.println("Customer = "+a2.getC1());
		a2.calculateInterest();

		Customer c3=(Customer) factory.getBean("c1");
		System.out.println("Customer directly created= "+c3);*/
	

	}

}
