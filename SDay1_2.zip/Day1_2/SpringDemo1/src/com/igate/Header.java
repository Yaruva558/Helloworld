package com.igate;

public class Header {

	public void printHeader()
	{
		System.out.println("***************");
		System.out.println("Demo Using Spring");
		System.out.println("***************");
	}
}
