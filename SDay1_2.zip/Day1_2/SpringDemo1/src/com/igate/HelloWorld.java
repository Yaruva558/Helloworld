package com.igate;

public class HelloWorld {

	public void sayHello()
	{
		System.out.println("Welcome to Spring");
	}
}

//To create object
//Helloworld h1=new HelloWorld();
