package com.igate;

public class Customer {

	public Customer() {
		super();
		System.out.println("In Customer Const...");
	}
	private String cname;
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	private String loc;
}
