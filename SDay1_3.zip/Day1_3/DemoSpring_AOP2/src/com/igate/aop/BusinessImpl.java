package com.igate.aop;

import java.sql.Connection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


//Target Class - has business methods
public class BusinessImpl{//implements Business{
	
	
	private void doBusiness() {
            System.out.println("I do what I do best, i.e sleep.");
            try {
         
                 Thread.sleep(200);
                 
            } catch (InterruptedException e) {
                    System.out.println("How dare you to wake me up?");
            }
            System.out.println("Done with sleeping.");
    }
    
	
    private void myBusinessMethod()
    {
    	System.out.println("========================");
    	System.out.println("In My BusinessMethod");
    }
    
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("business.xml");
        BusinessImpl bc = (BusinessImpl) context.getBean("myBusinessClass");
        
        bc.doBusiness();
        bc.myBusinessMethod();
        
                     
}

}