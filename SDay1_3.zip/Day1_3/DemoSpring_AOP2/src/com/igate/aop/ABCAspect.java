package com.igate.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class ABCAspect {

    @Pointcut("execution(* com.igate.aop.*.*(..))")
    public void m1() { }

    @Before("m1()")
    public void MyMethod(){
    	System.out.println("----------------------------");
    	System.out.println("AOP");
    	System.out.println("OOOOOOOOOOOPS-----Applying Before advice-----");
    }
}
